// Mock Data for Products
// ملاحظة هامة: الصور الآن يتم قراءتها من مجلد images
// لتغيير صورة، ضع الصورة في المجلد وسمها بنفس رقم المنتج (مثلاً 1.jpg)
const products = [
    {
        id: 1,
        name: "نعيمي بلدي (جذع)",
        category: "naimi",
        price: 1850,
        weight: "18-20 كجم",
        age: "5 شهور",
        image: "images/1.jpg",
        backup: "https://images.unsplash.com/photo-1484557985045-6f5e98487c9d?q=80&w=400&fit=crop"
    },
    {
        id: 2,
        name: "حري فاخر (جذع)",
        category: "hari",
        price: 1600,
        weight: "15-17 كجم",
        age: "4 شهور",
        image: "images/2.jpg",
        backup: "https://images.unsplash.com/photo-1516467508483-a7212febe31a?q=80&w=400&fit=crop"
    },
    {
        id: 3,
        name: "نعيمي بلدي (هرفي)",
        category: "naimi",
        price: 2100,
        weight: "22-25 كجم",
        age: "6 شهور",
        image: "images/3.jpg",
        backup: "https://images.unsplash.com/photo-1511117833895-4b473c0b85d6?q=80&w=400&fit=crop"
    },
    {
        id: 4,
        name: "سواكني تربية خاصة",
        category: "sawakni",
        price: 1100,
        weight: "20-22 كجم",
        age: "6 شهور",
        image: "images/4.jpg",
        backup: "https://images.unsplash.com/photo-1543033588-4e3fcc4183d2?q=80&w=400&fit=crop"
    },
    {
        id: 5,
        name: "تيس عارضي (لباني)",
        category: "hari",
        price: 1300,
        weight: "10-12 كجم",
        age: "3 شهور",
        image: "images/5.jpg",
        backup: "https://images.unsplash.com/photo-1594411122759-4537754f9d44?q=80&w=400&fit=crop"
    }
];

// DOM Elements
const productsGrid = document.getElementById('productsGrid');
const filterBtns = document.querySelectorAll('.filter-btn');
const modal = document.getElementById('bookingModal');
const closeModalBtn = document.querySelector('.close-modal');
const bookingForm = document.getElementById('bookingForm');
const successOverlay = document.getElementById('successOverlay');
const closeSuccessBtn = document.getElementById('closeSuccess');
const selectedProductTitle = document.getElementById('selectedProductTitle');
const productNameInput = document.getElementById('productName');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // 1. Inject M-Tech Ads (Protected Revenue Stream)
    injectMTechAds();

    // 2. Render Site
    renderProducts(products);
    setupEventListeners();

    // 3. Security Check (Anti-Tamper)
    // يتأكد كل 3 ثواني أن الإعلان موجود، إذا تم حذفه يوقف الموقع
    setInterval(checkIntegrity, 3000);
});

// --- M-Tech Hybrid Ads System (Google + Private) ---
function injectMTechAds() {
    const heroSection = document.querySelector('.hero');
    if (!heroSection) return;

    // حاوية الإعلانات (تجمع جوجل + الخاص)
    const adContainer = document.createElement('div');
    adContainer.id = "mtech-ads-wrapper";
    adContainer.style.cssText = "margin: 20px auto; max-width: 1200px; padding: 0 20px; text-align: center;";

    // 1. مساحة إعلانات جوجل (Google AdSense)
    // ضع كود جوجل هنا مستقبلاً
    const googleAdHTML = `
        <div class="google-ad-slot" style="margin-bottom: 15px; background: #F3F4F6; padding: 10px; border: 1px dashed #ccc; border-radius: 8px;">
            <p style="font-size: 0.75rem; color: #9CA3AF;">Google Ads Area</p>
            <!-- هنا يتم لصق سكربت جوجل ادسنس -->
            <div style="height: 90px; display: flex; align-items: center; justify-content: center; color: #aaa;">
                (مساحة مخصصة لكود Google AdSense)
            </div>
        </div>
    `;

    // 2. مساحة إعلاناتك الخاصة (M-Tech Private Ads)
    const privateAdHTML = `
        <div class="private-ad-slot">
            <p style="font-size: 0.8rem; color: #9CA3AF; margin-bottom: 5px; text-align: right;">رعاية رسمية (M-Tech)</p>
            <a href="https://wa.me/966500000000" target="_blank">
                <img src="https://via.placeholder.com/1200x120/2C5F2D/FFFFFF?text=مساحة+لشركات+الأعلاف+(إعلان+فائق+الجودة)" 
                     alt="M-Tech Ads" 
                     style="width: 100%; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            </a>
        </div>
    `;

    adContainer.innerHTML = googleAdHTML + privateAdHTML;
    heroSection.insertAdjacentElement('afterend', adContainer);
}

// (تم حذف كود الحماية checkIntegrity للسماح بمرونة كود جوجل)
// ------------------------------------

// Render Products Function
function renderProducts(items) {
    productsGrid.innerHTML = '';

    items.forEach(product => {
        const card = document.createElement('div');
        card.classList.add('product-card');
        card.innerHTML = `
            <img src="${product.image}" 
                 alt="${product.name}" 
                 class="product-image"
                 onerror="this.onerror=null; this.src='${product.backup}';"
            >
            <div class="product-info">
                <div class="product-header">
                    <h3 class="product-title">${product.name}</h3>
                    <span class="product-price">${product.price} ر.س</span>
                </div>
                <div class="product-details">
                    <span class="badge">⚖️ ${product.weight}</span>
                    <span class="badge">⏳ ${product.age}</span>
                </div>
                <button class="btn btn-primary full-width" onclick="openBooking(${product.id})">احجز الآن</button>
            </div>
        `;
        productsGrid.appendChild(card);
    });
}

// Filter Logic
filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        // Remove active class from all
        filterBtns.forEach(b => b.classList.remove('active'));
        // Add active to clicked
        btn.classList.add('active');

        const category = btn.getAttribute('data-filter');

        if (category === 'all') {
            renderProducts(products);
        } else {
            const filtered = products.filter(p => p.category === category);
            renderProducts(filtered);
        }
    });
});

// Modal Logic
let currentProductPrice = 0;
let appliedDiscount = 0; // نسبة الخصم
let appliedCouponCode = "";

function openBooking(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    // Reset State
    document.getElementById('quantity').value = 1;
    document.getElementById('couponCode').value = "";
    document.getElementById('couponMsg').textContent = "";
    document.getElementById('oldPrice').style.display = 'none';

    appliedDiscount = 0;
    appliedCouponCode = "";
    currentProductPrice = product.price;

    selectedProductTitle.textContent = `حجز: ${product.name}`;
    document.getElementById('modalWeight').textContent = product.weight;
    updatePriceDisplay();

    productNameInput.value = product.name;
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

// Coupons Database (قاعدة بيانات الكوبونات)
const COUPONS = {
    'MTECH': 0.10,   // خصم 10%
    'SAUDI': 0.15,   // خصم 15%
    'VIP': 0.20      // خصم 20%
};

function applyCoupon() {
    const codeInput = document.getElementById('couponCode');
    const msgEl = document.getElementById('couponMsg');
    const code = codeInput.value.trim().toUpperCase();

    if (COUPONS[code]) {
        appliedDiscount = COUPONS[code];
        appliedCouponCode = code;
        msgEl.textContent = `✅ تم تفعيل خصم ${(appliedDiscount * 100)}% بنجاح!`;
        msgEl.style.color = 'green';
        updatePriceDisplay();
    } else {
        appliedDiscount = 0;
        appliedCouponCode = "";
        msgEl.textContent = "❌ كود خاطئ أو منتهي الصلاحية";
        msgEl.style.color = 'red';
        updatePriceDisplay();
    }
}

// Quantity Logic (Called by HTML buttons)
function updateQty(change) {
    const qtyInput = document.getElementById('quantity');
    let newQty = parseInt(qtyInput.value) + change;
    if (newQty < 1) newQty = 1; // Minimum 1
    qtyInput.value = newQty;
    updatePriceDisplay();
}

// Update Total Price Display
function updatePriceDisplay() {
    const qty = parseInt(document.getElementById('quantity').value);
    const originalTotal = currentProductPrice * qty;

    // Calculate Discount
    const discountAmount = originalTotal * appliedDiscount;
    const finalTotal = originalTotal - discountAmount;

    const totalPriceEl = document.getElementById('totalPrice');
    const oldPriceEl = document.getElementById('oldPrice');

    totalPriceEl.textContent = finalTotal.toLocaleString() + ' ر.س';

    if (appliedDiscount > 0) {
        oldPriceEl.style.display = 'inline';
        oldPriceEl.textContent = originalTotal.toLocaleString();
    } else {
        oldPriceEl.style.display = 'none';
    }
}

// Expose functions
window.updateQty = updateQty;
window.applyCoupon = applyCoupon;

// Close Modal
function closeModal() {
    modal.classList.remove('active');
    document.body.style.overflow = 'auto'; // Restore scrolling
}

closeModalBtn.addEventListener('click', closeModal);

// Close on outside click
modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
});

// WhatsApp Integration Settings
const OWNER_PHONE = "966500000000"; // <--- ضع رقم جوالك هنا (مع مفتاح الدولة 966)

// Cutting Types Mapping (Translation)
const cuttingTypes = {
    'thallaja': 'ثلاجة (صغير)',
    'halves': 'أنصاف',
    'quarters': 'أرباع',
    'whole': 'كاملة (بدون تقطيع)'
};

// Form Submission
bookingForm.addEventListener('submit', (e) => {
    e.preventDefault();

    // Get Values
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    const date = document.getElementById('date').value;
    const cuttingVal = document.getElementById('cutting').value;
    const notes = document.getElementById('notes').value;
    const product = productNameInput.value;

    // Get Quantity & Total
    const qty = document.getElementById('quantity').value;
    const total = document.getElementById('totalPrice').textContent;

    // UI Feedback
    const submitBtn = bookingForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'جاري التحويل لواتساب...';
    submitBtn.disabled = true;

    // Construct WhatsApp Message
    let message = `*طلب حجز جديد 🐑*
---------------------------
*المنتج:* ${product}
*العدد:* ${qty}
*الإجمالي النهائي:* ${total}
`;

    if (appliedCouponCode) {
        message += `*كود الخصم:* ${appliedCouponCode} ✅\n`;
    }

    message += `---------------------------
*الاسم:* ${name}
*الجوال:* ${phone}
*التاريخ:* ${date}
*التقطيع:* ${cuttingTypes[cuttingVal]}
---------------------------
*ملاحظات:* ${notes ? notes : 'لا يوجد'}
`;

    // Create WhatsApp URL
    const whatsappUrl = `https://wa.me/${OWNER_PHONE}?text=${encodeURIComponent(message)}`;

    // Wait a moment then open WhatsApp and close modal
    setTimeout(() => {
        window.open(whatsappUrl, '_blank');

        // Reset UI
        closeModal();
        successOverlay.classList.remove('hidden');
        bookingForm.reset();
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }, 1000);
});

// Close Success Message
closeSuccessBtn.addEventListener('click', () => {
    successOverlay.classList.add('hidden');
});

// Set Floating WhatsApp Number dynamically
document.getElementById('floatingWhatsapp').href = `https://wa.me/${OWNER_PHONE}`;

// Expose openBooking to global scope
window.openBooking = openBooking;
